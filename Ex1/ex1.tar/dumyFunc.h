//
// Created by yohai.magen on 3/16/17.
//

#ifndef IMLEX1_DUMYFUNC_H
#define IMLEX1_DUMYFUNC_H

void dummyFunc();

#endif //IMLEX1_DUMYFUNC_H
