//
// Created by yohai.magen on 3/16/17.
//
#include "dumyFunc.h"

void dummyFunc(){}
